# YouTube NameCheck V1.1

This is the source project, not an APK. A ZIP containing an Android project cannot be installed directly on a phone.

## What changed
- Premium dark UI
- Removed the API-key field from the Android app
- Added secure backend architecture using a Cloudflare Worker
- Exact channel-name matching
- Similar-channel scoring
- Handle lookup with honest “not proof of availability” wording
- Name score

## To install

You need to build the project into an APK. Android Studio can build a debug APK; on an Android-only workflow, an Android-compatible IDE can also build Gradle Android projects.

After building, install the generated APK on your phone. Do not install the ZIP itself.

## Before live checks work

Deploy `backend/cloudflare-worker`, set the `YOUTUBE_API_KEY` Worker secret, then put the Worker URL into `BACKEND_URL` in `MainActivity.kt` and rebuild.
