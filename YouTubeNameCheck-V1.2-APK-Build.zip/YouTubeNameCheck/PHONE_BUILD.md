# Build the APK using only an Android phone

The project is prepared for a phone-only build through GitHub Actions. No PC is required.

1. Create/sign in to a GitHub account in Chrome on the phone.
2. Create a new repository.
3. Upload the contents of this ZIP to the repository, preserving the `YouTubeNameCheck/` folder and `.github/workflows/build-apk.yml`.
4. In GitHub: Actions → Build YouTube NameCheck APK → Run workflow.
5. Wait for the workflow to finish.
6. Open the completed workflow run → Artifacts → `YouTubeNameCheck-debug-apk`.
7. Download the ZIP artifact, extract it, and install `app-debug.apk` on Android.

For a working API connection, first deploy the Cloudflare Worker in `backend/cloudflare-worker/`, set the `YOUTUBE_API_KEY` Worker secret, then add the Worker URL as a GitHub repository secret named `BACKEND_URL`. Re-run the workflow.

The YouTube API key is never put into the Android app.
