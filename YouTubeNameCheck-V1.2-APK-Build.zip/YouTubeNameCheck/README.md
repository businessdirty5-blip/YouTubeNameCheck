# YouTube NameCheck V1.2

Android app + secure Cloudflare Worker backend for checking YouTube channel-name matches, @handle associations, similar channels, and a name score.

## Security
- YouTube API key lives only in the Cloudflare Worker secret `YOUTUBE_API_KEY`.
- Android receives only the Worker URL.
- Android build can receive the Worker URL through the Gradle property `BACKEND_URL`.
- Never commit the YouTube API key to GitHub.

## Build
See `PHONE_BUILD.md` for a phone-only GitHub Actions build.
