plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    buildFeatures { buildConfig = true }
    namespace = "com.namecheck.youtubenamcheck"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.namecheck.youtubenamcheck"
        minSdk = 24
        targetSdk = 35
        versionCode = 2
        versionName = "1.2"
        buildConfigField("String", "BACKEND_URL", "\"${project.findProperty("BACKEND_URL") ?: "https://YOUR-WORKER.workers.dev"}\"")
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
    implementation("org.json:json:20250107")
}
