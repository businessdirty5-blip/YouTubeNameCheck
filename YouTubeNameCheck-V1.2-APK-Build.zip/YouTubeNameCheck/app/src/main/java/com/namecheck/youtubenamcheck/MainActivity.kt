package com.namecheck.youtubenamcheck

import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.*
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import kotlin.math.roundToInt

private val BACKEND_URL: String get() = BuildConfig.BACKEND_URL

class MainActivity : AppCompatActivity() {
    private val client = OkHttpClient()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var nameInput: EditText
    private lateinit var handleInput: EditText
    private lateinit var results: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(11, 13, 18)
        window.navigationBarColor = Color.rgb(11, 13, 18)
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(11, 13, 18))
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 40)
        }

        val brand = TextView(this).apply {
            text = "NAMECHECK"
            textSize = 13f
            setTextColor(Color.rgb(255, 70, 70))
            letterSpacing = .18f
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        content.addView(brand)
        content.addView(TextView(this).apply {
            text = "Find your next\nYouTube name."
            textSize = 34f
            setTextColor(Color.WHITE)
            setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(0, 8, 0, 8)
        })
        content.addView(TextView(this).apply {
            text = "Check names, @handles and similar channels before you commit."
            textSize = 15f
            setTextColor(Color.rgb(166, 173, 187))
            setPadding(0, 0, 0, 24)
        })

        nameInput = input("Channel name", "e.g. Reality X")
        handleInput = input("YouTube handle", "e.g. @realityx")
        content.addView(nameInput, marginParams(0, 0, 0, 10))
        content.addView(handleInput, marginParams(0, 0, 0, 14))

        val check = Button(this).apply {
            text = "CHECK NAME  →"
            textSize = 15f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(255, 38, 38))
            setOnClickListener { checkAll() }
        }
        content.addView(check, marginParams(-1, 58, 0, 22))

        results = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(results)
        content.addView(TextView(this).apply {
            text = "Live results are powered by the official YouTube Data API through a secure server. A display name is not required to be unique."
            textSize = 12f
            setTextColor(Color.rgb(110, 118, 132))
            setPadding(4, 24, 4, 0)
        })
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun input(label: String, hint: String): EditText = EditText(this).apply {
        this.hint = hint
        textSize = 16f
        setSingleLine(true)
        setTextColor(Color.WHITE)
        setHintTextColor(Color.rgb(103, 111, 125))
        background = getDrawable(com.namecheck.youtubenamcheck.R.drawable.bg_input)
        setPadding(16, 0, 16, 0)
    }

    private fun marginParams(w: Int, h: Int, l: Int, t: Int): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(if (w == -1) -1 else -1, h).apply { leftMargin = l; rightMargin = l; topMargin = t }

    private fun checkAll() {
        val name = nameInput.text.toString().trim()
        val handle = handleInput.text.toString().trim()
        results.removeAllViews()
        if (name.isEmpty() && handle.isEmpty()) {
            card("START WITH A NAME", "Enter a channel name or @handle.", Color.rgb(255, 180, 50))
            return
        }
        if (BACKEND_URL.contains("YOUR-WORKER")) {
            card("BACKEND NOT CONNECTED", "Deploy the included Cloudflare Worker and replace BACKEND_URL in MainActivity.kt. No YouTube API key belongs in the app.", Color.rgb(255, 180, 50))
            return
        }
        card("CHECKING", "Searching YouTube…", Color.rgb(110, 170, 255))
        scope.launch {
            try {
                val result = withContext(Dispatchers.IO) { Api(client).check(name, handle) }
                results.removeAllViews()
                render(result)
            } catch (e: Exception) {
                results.removeAllViews()
                card("CHECK FAILED", e.message ?: "Server unavailable.", Color.rgb(255, 70, 70))
            }
        }
    }

    private fun render(d: CheckResult) {
        val exactColor = if (d.exactName) Color.rgb(255, 70, 70) else Color.rgb(70, 220, 140)
        card("CHANNEL NAME", if (d.exactName) "EXACT MATCHES FOUND" else "NO EXACT MATCH IN SEARCH RESULTS", exactColor)
        card("HANDLE", d.handleMessage, if (d.handleFound) Color.rgb(255, 180, 50) else Color.rgb(70, 220, 140))

        val scoreCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 18, 20, 18)
            background = getDrawable(R.drawable.bg_card)
        }
        val score = TextView(this).apply {
            text = "${d.score}/100"
            textSize = 40f
            setTextColor(Color.WHITE)
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        scoreCard.addView(TextView(this).apply { text = "NAME SCORE"; textSize = 12f; setTextColor(Color.rgb(150,158,172)) })
        scoreCard.addView(score)
        scoreCard.addView(TextView(this).apply { text = d.scoreLabel; textSize = 14f; setTextColor(Color.rgb(200,206,216)) })
        results.addView(scoreCard, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 12 })

        if (d.channels.isNotEmpty()) {
            results.addView(TextView(this).apply {
                text = "SIMILAR CHANNELS"
                textSize = 12f
                setTextColor(Color.rgb(150,158,172))
                setPadding(4, 10, 4, 8)
            })
            d.channels.take(10).forEach { c ->
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(18, 14, 18, 14)
                    background = getDrawable(R.drawable.bg_card)
                    setOnClickListener { open(c.url) }
                }
                row.addView(TextView(this).apply { text = c.title; textSize = 17f; setTextColor(Color.WHITE); setTypeface(null, android.graphics.Typeface.BOLD) })
                row.addView(TextView(this).apply { text = "${c.subscribers} subscribers  •  ${c.similarity}% similar"; textSize = 13f; setTextColor(Color.rgb(160,168,182)); setPadding(0, 5, 0, 0) })
                results.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 8 })
            }
        }
    }

    private fun card(title: String, message: String, accent: Int) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18, 14, 18, 14); background = getDrawable(R.drawable.bg_card) }
        box.addView(TextView(this).apply { text = title; textSize = 11f; setTextColor(accent); setTypeface(null, android.graphics.Typeface.BOLD) })
        box.addView(TextView(this).apply { text = message; textSize = 15f; setTextColor(Color.WHITE); setPadding(0, 5, 0, 0) })
        results.addView(box, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 10 })
    }

    private fun open(url: String) { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }

    override fun onDestroy() { scope.cancel(); super.onDestroy() }
}

data class Channel(val title: String, val subscribers: String, val similarity: Int, val url: String)
data class CheckResult(val exactName: Boolean, val handleFound: Boolean, val handleMessage: String, val score: Int, val scoreLabel: String, val channels: List<Channel>)

class Api(private val client: OkHttpClient) {
    fun check(name: String, handle: String): CheckResult {
        val url = BACKEND_URL.trimEnd('/') + "/check?name=" + Uri.encode(name) + "&handle=" + Uri.encode(handle)
        val request = Request.Builder().url(url).get().build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) throw IllegalStateException("Server returned ${response.code}")
            val obj = JSONObject(response.body?.string() ?: error("Empty response"))
            val arr = obj.optJSONArray("channels")
            val list = mutableListOf<Channel>()
            if (arr != null) for (i in 0 until arr.length()) {
                val c = arr.getJSONObject(i)
                list += Channel(c.optString("title"), c.optString("subscribers"), c.optInt("similarity"), c.optString("url"))
            }
            CheckResult(obj.optBoolean("exactName"), obj.optBoolean("handleFound"), obj.optString("handleMessage"), obj.optInt("score"), obj.optString("scoreLabel"), list)
        }
    }
}
