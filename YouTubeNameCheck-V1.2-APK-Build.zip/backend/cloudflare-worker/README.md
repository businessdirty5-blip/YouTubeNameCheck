# YouTube NameCheck secure backend

This Cloudflare Worker keeps the YouTube Data API key on the server. The Android app never contains the YouTube API key.

## Deploy

1. Create a Cloudflare account and a Worker.
2. Deploy `worker.js` (Wrangler can also be used).
3. Add a Worker secret named `YOUTUBE_API_KEY` containing your Google Cloud YouTube Data API key.
4. Copy the Worker URL.
5. In the Android project, replace `BACKEND_URL` in `MainActivity.kt` with that Worker URL.
6. Build the Android app again.

The backend uses YouTube `search.list` for channel-name discovery and `channels.list` for channel details/handle lookup. A missing `forHandle` result is intentionally NOT labeled “available”, because the API result alone cannot prove that YouTube will allow a handle to be claimed.

## Important quota note

YouTube currently documents `search.list` as 1 quota unit per call, with a separate default daily search quota of 100 calls. `channels.list` costs 1 unit per call. Avoid unnecessary repeated searches and add caching/rate limiting before public launch.

## Public-launch hardening

Before a large public launch, add per-IP/user rate limiting, request logging without sensitive data, caching, abuse protection, and a stricter CORS allowlist. Keep the API key only as a server-side secret.
