const YT = 'https://www.googleapis.com/youtube/v3';

function cors() {
  return {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Cache-Control': 'no-store'
  };
}

function norm(s) {
  return (s || '').toLowerCase().normalize('NFKC').replace(/[^a-z0-9]+/g, ' ').trim().replace(/\s+/g, ' ');
}

function similarity(a, b) {
  a = norm(a); b = norm(b);
  if (!a || !b) return 0;
  if (a === b) return 100;
  if (a.includes(b) || b.includes(a)) return Math.round(85 * Math.min(a.length, b.length) / Math.max(a.length, b.length) + 10);
  const aa = new Set(a.split(' ')), bb = new Set(b.split(' '));
  const inter = [...aa].filter(x => bb.has(x)).length;
  const union = new Set([...aa, ...bb]).size;
  const jaccard = union ? inter / union : 0;
  const lev = levenshtein(a, b);
  const levScore = 1 - lev / Math.max(a.length, b.length);
  return Math.max(0, Math.min(100, Math.round((jaccard * 0.55 + levScore * 0.45) * 100)));
}

function levenshtein(a, b) {
  const row = Array.from({length: b.length + 1}, (_, i) => i);
  for (let i = 1; i <= a.length; i++) {
    let prev = row[0]; row[0] = i;
    for (let j = 1; j <= b.length; j++) {
      const cur = row[j];
      row[j] = Math.min(row[j] + 1, row[j - 1] + 1, prev + (a[i - 1] === b[j - 1] ? 0 : 1));
      prev = cur;
    }
  }
  return row[b.length];
}

function score(exact, topSimilarity, handleFound, name) {
  let s = 100;
  if (exact) s -= 45;
  else if (topSimilarity >= 90) s -= 35;
  else if (topSimilarity >= 75) s -= 22;
  else if (topSimilarity >= 60) s -= 10;
  if (handleFound) s -= 25;
  if (name.length > 24) s -= 8;
  return Math.max(0, Math.min(100, s));
}

function label(s) {
  if (s >= 85) return 'Strong candidate';
  if (s >= 70) return 'Good, but check competitors';
  if (s >= 50) return 'Crowded name';
  return 'High conflict risk';
}

async function yt(path, params, key) {
  const u = new URL(YT + path);
  Object.entries({...params, key}).forEach(([k, v]) => u.searchParams.set(k, v));
  const r = await fetch(u);
  if (!r.ok) throw new Error(`YouTube API ${r.status}`);
  return r.json();
}

export default {
  async fetch(request, env) {
    if (request.method === 'OPTIONS') return new Response('', {headers: cors()});
    const url = new URL(request.url);
    if (url.pathname === '/health') return new Response(JSON.stringify({ok:true}), {headers:{...cors(),'Content-Type':'application/json'}});
    if (url.pathname !== '/check') return new Response('Not found', {status:404, headers:cors()});
    if (!env.YOUTUBE_API_KEY) return new Response(JSON.stringify({error:'Server API key is not configured'}), {status:500, headers:{...cors(),'Content-Type':'application/json'}});

    const name = (url.searchParams.get('name') || '').trim().slice(0, 100);
    const handle = (url.searchParams.get('handle') || '').trim().slice(0, 100);
    if (!name && !handle) return new Response(JSON.stringify({error:'Enter a channel name or handle'}), {status:400, headers:{...cors(),'Content-Type':'application/json'}});

    try {
      let channels = [];
      if (name) {
        const search = await yt('/search', {part:'snippet', type:'channel', q:name, maxResults:'25'}, env.YOUTUBE_API_KEY);
        const ids = (search.items || []).map(x => x.id?.channelId).filter(Boolean).join(',');
        if (ids) {
          const detail = await yt('/channels', {part:'snippet,statistics', id:ids}, env.YOUTUBE_API_KEY);
          channels = (detail.items || []).map(c => ({
            title: c.snippet?.title || '',
            subscribers: c.statistics?.hiddenSubscriberCount ? 'Hidden' : Number(c.statistics?.subscriberCount || 0).toLocaleString(),
            similarity: similarity(name, c.snippet?.title || ''),
            url: `https://www.youtube.com/channel/${c.id}`,
            exact: norm(name) === norm(c.snippet?.title || '')
          })).sort((a,b) => b.similarity - a.similarity);
        }
      }

      let handleFound = false;
      let handleMessage = 'No handle checked';
      if (handle) {
        const h = handle.replace(/^@/, '');
        const data = await yt('/channels', {part:'snippet', forHandle:h}, env.YOUTUBE_API_KEY);
        handleFound = (data.items || []).length > 0;
        handleMessage = handleFound
          ? 'Handle is currently associated with a channel'
          : 'No channel returned for this handle — this does NOT guarantee the handle is available';
      }

      const exactName = channels.some(c => c.exact);
      const top = channels[0]?.similarity || 0;
      const s = score(exactName, top, handleFound, name);
      const body = JSON.stringify({exactName, handleFound, handleMessage, score:s, scoreLabel:label(s), channels});
      return new Response(body, {headers:{...cors(),'Content-Type':'application/json'}});
    } catch (e) {
      return new Response(JSON.stringify({error:String(e.message || e)}), {status:502, headers:{...cors(),'Content-Type':'application/json'}});
    }
  }
};
